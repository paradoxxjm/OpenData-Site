<?php
	define('DB_HOST', 'localhost');
    define('DB_USER', 'gisuser');
    define('DB_PASSWORD', 'gisuser');
    define('DB_DATABASE', 'gis');
?>